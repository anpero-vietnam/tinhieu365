﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Ultil
{
    public static class ImagesResize
    {

        public static System.IO.Stream ScaleImage(System.IO.Stream stream, int maxWidth, int maxHeight)
        {
            Image image = System.Drawing.Image.FromStream(stream);
            var width = image.Width;
            var height = image.Height;
            var newWidth = 0;
            var newHeight = 0;
            var divisor = 0;
            if (width > height)
            {
                if (width > maxWidth)
                {
                    divisor = (width * 1000) / maxWidth;
                    if (divisor == 0)
                    {
                        divisor = 1;
                    }
                    newHeight = Convert.ToInt32(((height * 100000) / divisor) / 100);
                    newWidth = Convert.ToInt32(((width * 100000) / divisor) / 100);
                }
                else
                {
                    newHeight = height;
                    newWidth = width;
                }
            }
            else
            {
                if (height > maxHeight)
                {
                    divisor = (height * 1000) / maxHeight;
                    if (divisor == 0)
                    {
                        divisor = 1;
                    }
                    newWidth = Convert.ToInt32(((width * 100000) / divisor) / 100);
                    newHeight = Convert.ToInt32(((height * 100000) / divisor) / 100);
                }
                else
                {
                    newHeight = height;
                    newWidth = width;
                }
            }
            var newImage = new Bitmap(newWidth, newHeight);
            Graphics.FromImage(newImage).DrawImage(image, 0, 0, newWidth, newHeight);
            return ToStream(newImage);

        }
        public static Stream ToStream(this System.Drawing.Image image)
        {
            var stream = new System.IO.MemoryStream();
            //stream.ReadTimeout = 100000;
            image.Save(stream, ImageFormat.Jpeg);
            stream.Position = 0;
            //stream.ReadTimeout = 100000;
            return stream;
        }

    }
    public class StreamBusiness
    {
        public String UploadFullFiles(System.IO.Stream File, String ServerMappath, String userName, String fileName)
        {

            String extension = System.IO.Path.GetExtension(fileName);

            try
            {

                if (extension == ".jpg" || extension == ".jpeg" || extension == ".gif" || extension == ".png" || extension == ".ico")
                {
                    String path = getNewFileName(fileName, ServerMappath, userName);
                    String serverPath = HttpContext.Current.Server.MapPath(path);
                    String DirectorysPath = HttpContext.Current.Server.MapPath(ServerMappath + userName + "/" + Ultil.Times.getSortStringByTimeNow());
                    if (!System.IO.Directory.Exists(DirectorysPath))
                    {
                        System.IO.Directory.CreateDirectory(DirectorysPath);
                    }
                    using (var fileStream = new FileStream(serverPath + extension, FileMode.Create, FileAccess.Write))
                    {
                        File.CopyTo(fileStream);
                    }
                    File.Dispose();
                    return path.Replace("~", String.Empty) + extension;


                }
                else
                {
                    return "/noimages.gif";
                }

            }
            catch (Exception)
            {

                throw;
            }
        }
        public String UploadFiles(System.IO.Stream File, string ServerMappath, string userName, string fileName, int maxWidth, int maxHeight, int MaxLengthFile)
        {

            String extension = System.IO.Path.GetExtension(fileName);
            string[] whiteList = { ".jpg", ".jpeg", ".gif", ".png", ".ico" };
            try
            {

                if (whiteList.Contains(extension.ToLower()))
                {

                    if (File.Length < MaxLengthFile && File.Length > 0)
                    {
                        System.Drawing.Image image;
                        System.IO.Stream streams = null;
                        if (maxWidth != 0)
                        {
                            streams = ImagesResize.ScaleImage(File, maxWidth, maxHeight);
                            image = System.Drawing.Image.FromStream(streams);

                        }
                        else
                        {
                            image = System.Drawing.Image.FromStream(File);
                        }
                        String path = getNewFileName(fileName, ServerMappath, userName);

                        //ĐƯờng dẫn tuyệt đối trên server để lưu file ex c://document/...
                        String serverPath = HttpContext.Current.Server.MapPath(path);
                        String DirectorysPath = HttpContext.Current.Server.MapPath(ServerMappath + userName + "/" + Ultil.Times.getSortStringByTimeNow());
                        if (!System.IO.Directory.Exists(DirectorysPath))
                        {
                            System.IO.Directory.CreateDirectory(DirectorysPath);

                        }
                        image.Save(serverPath + ".jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
                        File.Dispose();
                        image.Dispose();
                        if (streams != null)
                        {
                            streams.Dispose();
                        }
                        return path.Replace("~", String.Empty) + ".jpg";

                    }
                    else
                    {
                        return @"/noimages.gif";

                    }
                }
                else
                {
                    return "/noimages.gif";
                }

            }
            catch (Exception)
            {
                throw;
            }
        }
        private String getNewFileName(String fileName, String ServerMappath, String userName)
        {

            //lấy chuỗi theo milisicon+secon+munuites+hor+month+year

            String s = Ultil.Times.GetYYYYMMDDHHmmssmsNow();

            String fileWithNoExtenSion = Ultil.StringHelper.RemoveExtenSion(fileName);
            //tạo một tên file mới đã thêm một chuỗi ngẫu nhiên tránh trùng file
            String newFileName = Ultil.StringHelper.ToURLgach(fileWithNoExtenSion) + s;// +extension;
                                                                                       //tạo đường dẫn cho fie + tên file mới tránh trùng file với đường dẫn tương đỗi là tham số truyền vào 
                                                                                       //~/path/timenow/fire_name
            return ServerMappath + userName + "/" + Ultil.Times.getSortStringByTimeNow() + "/" + newFileName;

        }
        private System.IO.Stream ToStream(System.Drawing.Image image)
        {
            var stream = new System.IO.MemoryStream();
            //stream.ReadTimeout = 100000;
            image.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg);
            stream.Position = 0;
            //stream.ReadTimeout = 100000;
            return stream;
        }
        private System.Drawing.Image clonImages(System.Drawing.Image img)
        {

            Graphics graphicImage = Graphics.FromImage(img);

            graphicImage.SmoothingMode = SmoothingMode.AntiAlias;
            //Write your text.
            System.Drawing.Image imageFilea = System.Drawing.Image.FromFile(HttpContext.Current.Server.MapPath("~/images/logoClon.png"));
            graphicImage.DrawImage(imageFilea, new Point(img.Width - 5, img.Height - 5));
            return img;
        }
    }


}
