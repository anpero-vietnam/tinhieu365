﻿using AEnum;
using ServiceStack.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ultil.Cache
{
    internal class RedisCacheProvider : ICacheProvider
    {
        RedisEndpoint _endPoint;
        public RedisCacheProvider()
        {
            _endPoint = new RedisEndpoint(SiteConfig.RedisIP,SiteConfig.RedisPort,SiteConfig.RedisPass);
            
        }
        public void Set<T>(string key, T value)
        {
            this.Set(key, value,0);
        }
        public void Set<T>(string key, T value, double minuteTimeout)
        {
            var timeOut = TimeSpan.FromMinutes(minuteTimeout);
            if (minuteTimeout == 0)
            {
                timeOut = TimeSpan.Zero;
            }
            using (RedisClient client = new RedisClient(_endPoint))
            {
                client.As<T>().SetValue(key, value, TimeSpan.FromMinutes(minuteTimeout));
            }
        }
        public T Get<T>(string key)
        {
            T result = default(T);

            using (RedisClient client = new RedisClient(_endPoint))
            {
                var wrapper = client.As<T>();

                result = wrapper.GetValue(key);
            }
            return result;
        }
        public bool TryGet<T>(string key, out T outPut)
        {
            T result = default(T);

            using (RedisClient client = new RedisClient(_endPoint))
            {
                var wrapper = client.As<T>();
                result = wrapper.GetValue(key);
            }
            outPut = result;
            return result == null ? false : true;
        }
        
        public bool Remove(string key)
        {
            bool removed = false;

            using (RedisClient client = new RedisClient(_endPoint))
            {
                removed = client.Remove(key);
            }

            return removed;
        }
        public  bool ResetAllCache()
        {
            try
            {
                using (RedisClient client = new RedisClient(_endPoint))
                {
                    var keyList= client.GetAllKeys();
                    if (keyList != null)
                    {
                        foreach (var item in keyList)
                        {
                            client.Remove(item);
                        }
                    }
                }
                return true;
            }
            catch
            {

            }

            return false;
        }
        //public bool IsInCache(string key)
        //{
        //    bool isInCache = false;

        //    using (RedisClient client = new RedisClient(_endPoint))
        //    {
        //        isInCache = client.ContainsKey(key);
        //    }

        //    return isInCache;
        //}
    }
}
