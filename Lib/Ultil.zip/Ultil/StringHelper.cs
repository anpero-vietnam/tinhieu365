﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;

namespace Ultil
{
  
    public static class StringHelper
    {
        
        public static string AutoCreateHtmlTable(System.Data.DataTable DataTables, string mapPingColunmName, List<string> ignoreColunm)
        {
            string outPut = "<table class=\"table\">";
            List<string> columnNames = new List<string>();
            Boolean haveData = false;
            if (DataTables != null && DataTables.Rows.Count > 0)
            {
                haveData = true;
            }
            if (haveData)
            {
                outPut += "<tr>";
                for (int i = 0; i < DataTables.Columns.Count; i++)
                {
                    if (ignoreColunm != null)
                    {
                        if (!ignoreColunm.Contains(DataTables.Columns[i].ColumnName))
                        {
                            outPut += "<th>" + Ultil.StringHelper.MultiTextReplace(DataTables.Columns[i].ColumnName, mapPingColunmName) + "</th>";
                        }
                            
                    }
                    else
                    {
                        outPut += "<th>" + Ultil.StringHelper.MultiTextReplace(DataTables.Columns[i].ColumnName, mapPingColunmName) + "</th>";
                    }
                }
                outPut += "</tr>";
                if (DataTables != null && DataTables.Rows.Count > 0)
                {
                    for (int i = 0; i < DataTables.Rows.Count; i++)
                    {
                        outPut += "<tr>";
                        for (int j = 0; j < DataTables.Columns.Count; j++)
                        {
                            if (ignoreColunm != null)
                            {
                                if (!ignoreColunm.Contains(DataTables.Columns[i].ColumnName))
                                {
                                    outPut += "<td>" +( DBNull.Value == DataTables.Rows[i][j]?"":DataTables.Rows[i][j].ToString())+ "</td>";

                                }

                            }
                            else
                            {
                                outPut += "<td>" + (DBNull.Value == DataTables.Rows[i][j] ? "" : DataTables.Rows[i][j].ToString()) + "</td>";

                            }

                        }
                        outPut += "</tr>";
                    }
                }
                outPut += "</tr>";
            }


            return outPut += "</table>";
        }
        public static String RemoveExtenSion(String FileName)
        {
            int i = FileName.IndexOf(".");
            String NewFileName = FileName.Substring(0, i);
            NewFileName = RemoveHtmlTangs(NewFileName);
            if (NewFileName.Length > 20)
            {
                NewFileName = NewFileName.Substring(0, 20);
            }
            return NewFileName;
        }
        public static String RemoveATangs(String s)
        {
            return Regex.Replace(s, @"<a\b[^>]+>([^<]*(?:(?!</a)<[^<]*)*)</a>", "$1");

        }

        public static String ToEndcodedingLeveForum(String s)
        {
            if (s != null)
            {
                s = s.Replace(@"'", @" &quot;");
                s = s.Replace(@"\u003c", "[");
                s = s.Replace(@"&quot;", @" &quot;");
                s = s.Replace("<br />", "[br /]");
                s = s.Replace("<table>", "[table]");

                s = s.Replace("<strong>", "[strong]");
                s = s.Replace("</strong>", "[/strong]");

                s = s.Replace("<tr>", "[tr]");

                s = s.Replace("<i>", "[i]");
                s = s.Replace("</i>", "[/i]");

                s = s.Replace("<ul>", "[ul]");
                s = s.Replace("</ul>", "[/ul]");

                s = s.Replace("<li>", "[li]");
                s = s.Replace("</li>", "[/li]");


                s = s.Replace("<em>", "[em]");
                s = s.Replace("</em>", "[/em]");


                s = s.Replace("<b>", "[b]");
                s = s.Replace("</b>", "[/b]");

                s = s.Replace("<code>", "[code]");
                s = s.Replace("</code>", "[/code]");

                s = s.Replace("<tr>", "[tr]");
                s = s.Replace("</tr>", "[/tr]");

                s = s.Replace("<td>", "[td]");
                s = s.Replace("</td>", "[/td]");

                s = s.Replace("</h3>", "[/h3]");
                s = s.Replace("<h3>", "[h3]");

                s = s.Replace("<h4>", "[h4]");
                s = s.Replace("<h4>", "[h4]");

                s = s.Replace("</h5>", "[/h5]");
                s = s.Replace("<h5>", "[h5]");

                s = RemoveImgTangs(s);
                s = Ultil.StringHelper.RemoveScript(s);
                s = RemoveHtmlTangs(s);

                /// remove atag fist

                s = s.Replace(">", "]");

                //dau nho hon 10,16,html, unicode
                s = s.Replace("<", "[");
                s = s.Replace(@"&#60", "[");
                s = s.Replace(@"&#x3C", "[");
                s = s.Replace(@"&lt;", "[");
                s = s.Replace(@"\u003c", "[");

                s = s.Replace("--", "_");


                //dau nhay don 10,16,html, unicode
                s = s.Replace("'", "");
                s = s.Replace(@"&#39", "");
                s = s.Replace(@"&#x27", "");
                s = s.Replace(@"&apos;", "");
                s = s.Replace(@"\u0027", "");
                s = HttpUtility.HtmlEncode(s);
                s = s.Replace(@"&amp;nbsp;", "&nbsp;");
                s = s.Replace(@"&amp;quot;", "&quot;");
                return s;

            }
            else
            {
                return "";
            }
        }
        /// <summary>
        /// trả về chuỗi html phân trang
        /// </summary>
        /// <param name="curentPage">Trang hiện tại</param>
        /// <param name="pageSite">Số tin trên trang</param>
        /// <param name="newsCount">Tổng số tin</param>
        /// <param name="MaxPage">Số phân trang tối đa, số trang tối đa trong menu phân trang</param>
        ///<param name="query">query có dạng /page hoặc ?page</param>
        /// <returns>String</returns> 
        public static string SetUpPagedV2(int curentPage, int pageSite, int newsCount, int MaxPage, String query)
        {
            String pagedString = "";
            query = query.Replace(@"?", "").Replace(@"&", "");
            int totallPaed = newsCount / pageSite;
            if (newsCount % pageSite > 0)
            {
                totallPaed += 1;
            }
            #region get link
            string CurentUrl = HttpContext.Current.Request.RawUrl.ToString();
            String pageaspx = CurentUrl;
            int legth = CurentUrl.LastIndexOf("?" + query);
            if (legth > 0)
            {
                pageaspx = CurentUrl.Substring(0, legth);
            }
            else
            {
                legth = CurentUrl.LastIndexOf("&" + query);
                if (legth > 0)
                {
                    pageaspx = CurentUrl.Substring(0, legth);
                }
            }
            if (pageaspx.Contains(@"?"))
            {
                query = "&" + query;
            }
            else
            {
                query = "?" + query;
            }
            #endregion
            // string path = HttpContext.Current.Request.Url.AbsolutePath;
            // // /TESTERS/Default6.aspx
            //nếu số tin lới hơn số tin trên trang mới hiển thị phân trang
            if (newsCount > pageSite)
            {
                pagedString = "<ul class='pagination'>";
                if (curentPage == 1)
                {
                    pagedString += @"<li><a href='javascript:void(0);' tittle='Bạn đang ở trang đầu'>&laquo;</a></li>";
                }
                else
                {
                    pagedString += @"<li><a href='" + pageaspx + query + (curentPage - 1) + "'>&laquo;</a></li>";
                }

                if (curentPage <= totallPaed)
                {
                    //gioi han hien tai cua phan trang
                    int j = curentPage + MaxPage;
                    int k = MaxPage;
                    if (k <= totallPaed)
                    {
                        k = totallPaed;
                    }
                    if (j >= k)
                    {
                        j = totallPaed;
                    }
                    int currenttag;
                    if (curentPage == 1 || curentPage == 2 || curentPage == 3)
                    {
                        currenttag = 1;
                    }
                    else
                    {
                        currenttag = curentPage - 2;
                    }

                    for (int i = currenttag; i < j; i++)
                    {
                        if (i == curentPage)
                        {
                            pagedString += @"<li class='active'><a href='javascript:void(0);' tittle='đang ở trang này'>" + (i) + "</a><li>";

                        }
                        else
                        {
                            pagedString += @"<li><a href='" + pageaspx + query + i + "'>" + i + "</a></li>";
                        }

                    }



                }

                if (curentPage == totallPaed)
                {
                    pagedString += @"<li class='active'><a href='javascript:void(0);' tittle='bạn đang ở trang cuôi'>&raquo;</a><li>";

                }
                else
                {
                    pagedString += @"<li><a href='" + pageaspx + query + totallPaed + @"'> . " + totallPaed + @"</a></li>";
                    pagedString += @"<li><a href='" + pageaspx + query + (curentPage + 1) + "'>&raquo;</a></li>";

                }
                pagedString += @"</ul>";
            }



            return pagedString;
        }
        public static String RemoveImgTangs(String s)
        {


            return Regex.Replace(s, @"<img\b[^>]+>", string.Empty);

        }
        /// <summary>
        /// hàm này xóa triệt để các thành phần html chỉ giữ lại một số thẻ cơ bản và chuyển sang encode
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static String HtmlDecodeIngLeverForum(String s)
        {
            s = s.Replace("''", "'");
            s = s.Replace(@"&#60", "[");
            s = s.Replace(@"&#x3C", "[");

            s = s.Replace(@"\u003c", "[");
            s = s.Replace(@"&quot;", @" &quot;");
            s = s.Replace("[br /]", "<br />");
            s = s.Replace("[table]", "<table>");

            s = s.Replace("[strong]", "<strong>");
            s = s.Replace("[/strong]", "</strong>");

            s = s.Replace("[tr]", "<tr>");


            s = s.Replace("[/span]", "</span>");

            s = s.Replace("[b]", "<b>");
            s = s.Replace("[/b]", "</b>");
            s = s.Replace("[code]", "<code>");
            s = s.Replace("[/code]", "</code>");
            s = s.Replace("[/tr]", "</tr>");
            s = s.Replace("[td]", "<td>");
            s = s.Replace("[/td]", "</td>");


            s = s.Replace("[em]", "<em>");
            s = s.Replace("[/em]", "</em>");

            s = s.Replace("[/h3]", "</h3>");
            s = s.Replace("[h3]", "<h3>");

            s = s.Replace("[h4]", "<h4>");
            s = s.Replace("[br]", "<br>");

            s = s.Replace("[h4]", "<h4>");

            s = s.Replace("[/h5]", "</h5>");

            s = s.Replace("[h5]", "<h5>");

            s = s.Replace("[i]", "<i>");
            s = s.Replace("[/i]", "</i>");
            s = HttpUtility.HtmlDecode(s);
            s = Ultil.StringHelper.imgBBCodeToImgTag(s);
            s = RemoveScript(s);
            s = RemoveIframe(s);
            return s;
        }
        public static String RemoveHtmlTagLevelAdmin(String s)
        {
            s = s.Replace("''", "'");
            s = s.Replace(@"&#60", "[");
            s = s.Replace(@"&#x3C", "[");
            s = s.Replace(@"\u003c", "[");
            s = s.Replace(@"&quot;", @" &quot;");
            s = s.Replace(@"\u003c", "[");
            s = s.Replace(@"&quot;", @" &quot;");
            s = s.Replace("<br />", "[br /]");
            s = s.Replace("<table>", "[table]");

            s = s.Replace("<strong>", "[strong]");
            s = s.Replace("</strong>", "[/strong]");



            s = s.Replace("''", "'");

            s = s.Replace(@"&#60", "[");

            s = s.Replace(@"&#x3C", "[");


            s = s.Replace(@"\u003c", "[");
            s = s.Replace(@"&quot;", @" &quot;");
            s = s.Replace("[br /]", "<br />");
            s = s.Replace("[table]", "<table>");

            s = s.Replace("[strong]", "<strong>");
            s = s.Replace("[/strong]", "</strong>");

            s = s.Replace("[tr]", "<tr>");
            s = s.Replace("[/tr]", "</tr>");

            s = s.Replace("[td]", "<td>");
            s = s.Replace("[/td]", "</td>");
            s = s.Replace("[br]", "<br>");


            s = s.Replace("[/span]", "</span>");

            s = s.Replace("[b]", "<b>");
            s = s.Replace("[/b]", "</b>");

            s = s.Replace("[code]", "<code>");
            s = s.Replace("[/code]", "</code>");

            s = s.Replace("[em]", "<em>");
            s = s.Replace("[/em]", "</em>");

            s = s.Replace("[/h3]", "</h3>");
            s = s.Replace("[h3]", "<h3>");

            s = s.Replace("[h4]", "<h4>");

            s = s.Replace("[h4]", "<h4>");

            s = s.Replace("[/h5]", "</h5>");

            s = s.Replace("[h5]", "<h5>");

            s = s.Replace("[i]", "<i>");
            s = s.Replace("[/i]", "</i>");

            s = s.Replace("[/p]", "</p>");
            s = s.Replace("[p]", "<p>");
            s = RemoveScript(s);
            s = RemoveIframe(s);
            return s;
        }
        public static String RemoveIframe(String s)
        {
            return Regex.Replace(s, "<iframe.*?</iframe>", "", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        }
        public static String RemoveCss(String s)
        {
            return Regex.Replace(s, "<style.*?</style>", "", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        }
        public static string MultiTextReplace(string input, string mapping)
        {
            if (!string.IsNullOrEmpty(mapping))
            {
                string[] mapingList = mapping.Split(',');
                if (mapingList.Length > 0)
                {
                    for (int i = 0; i < mapingList.Length; i++)
                    {
                        if (!string.IsNullOrEmpty(mapingList[i]))
                        {
                            string[] rule = mapingList[i].Split('>');
                            input = Regex.Replace(input, rule[0].Trim(), rule[1].Trim(), RegexOptions.IgnoreCase);
                            if (input.Equals(rule[1].Trim()))
                                return input;
                        }
                    }
                }
            }
            return input;
        }
        public static Boolean isInternetUrl(String url)
        {
            string pattern = @"http(s)?://([\w-]+\.)+[\w-]+(/[\w- ./?%&=]*)?";

            if (Regex.IsMatch(url, pattern, RegexOptions.IgnoreCase))
            {
                return true;

            }
            else
            {


                return false;
            }

        }
        public static string URLBBCodeToATag(String s)
        {
            s = Regex.Replace(s, @"\[URL\](http(s)?://([\w-]+\.)+[\w-]+(/[\w- ./?%&=]*)?)\[\/URL\]", @"<a href=""$1"" target='_blank' rel='nofollow'/>$1</a>", RegexOptions.IgnoreCase);
            return s;
        }
        public static Boolean isEmail(String Email)
        {

            // string pattern = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
            try
            {
                if (Email != null)
                {
                    return Regex.IsMatch(Email, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");

                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {

                return false;
            }


        }
        public static Boolean isYouToBeLink(String link)
        {


            try
            {
                string pattern = @"^http://youtu.be/([A-Z0-9]*_?\-?[A-Z0-9]*)*$";
                if (Regex.IsMatch(link, pattern, RegexOptions.IgnoreCase))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        public static String GetYouTubeAgument(String link)
        {
            try
            {

                int lengths = link.Length;
                int i = link.LastIndexOf("/");
                return link.Substring(i, lengths - i);
            }
            catch (Exception)
            {
                return "";
            }
        }
        public static string imgBBCodeToImgTag(String s)
        {
            s = Regex.Replace(s, @"\[IMG\](https?://(?:[a-z0-9\-\.]+\.)+[a-z0-9]{2,6}(?:/[^/#?]+)+\.(?:jpg|gif|png|jpeg))\[\/IMG\]", @"<img src=""$1""/>", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\[IMG alt=""([^/><*&?]+)""\](https?://(?:[a-z0-9\-\.]+\.)+[a-z0-9]{2,6}(?:/[^/#?]+)+\.(?:jpg|gif|png|jpeg))\[\/IMG\]", @"<img src=""$2"" alt=""$1""/>", RegexOptions.IgnoreCase);
            return s;
        }
        public static string ImgTagtoimgBBCode(String s)
        {
            s = Regex.Replace(s, @"<img src=""(https?://(?:[a-z0-9\-\.]+\.)+[a-z0-9]{2,6}(?:/[^/#?]+)+\.(?:jpg|gif|png|jpeg))"">", @"[IMG]$1[/IMG]", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"<img src=""(https?://(?:[a-z0-9\-\.]+\.)+[a-z0-9]{2,6}(?:/[^/#?]+)+\.(?:jpg|gif|png|jpeg))"" \/>", @"[IMG]$1[/IMG]", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"<img src=""(https?://(?:[a-z0-9\-\.]+\.)+[a-z0-9]{2,6}(?:/[^/#?]+)+\.(?:jpg|gif|png|jpeg))"" alt=""([^/><*&?]+)""\/>", @"[IMG alt=""$2""]$1[/IMG]", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"<img src=""(https?://(?:[a-z0-9\-\.]+\.)+[a-z0-9]{2,6}(?:/[^/#?]+)+\.(?:jpg|gif|png|jpeg))"" alt=""([^/><*&?]+)"">", @"[IMG alt=""$2""]$1[/IMG]", RegexOptions.IgnoreCase);
            return s;
        }
        public static String RemoveScript(String s)
        {
            ///check
            ///
            if (string.IsNullOrEmpty(s))
            {

                return s;
            }
            else
            {
                s = s.Replace("--", "_");
                s = s.Replace("'", "");

            }

            return Regex.Replace(s, "<script.*?</script>", "", RegexOptions.Singleline | RegexOptions.IgnoreCase);

        }
        public static String checkHackSql(String s)
        {
            s = s.ToLower();
            s = RemoveScript(s);
            s = s.Replace("--", "_");
            s = s.Replace("'", "");
            s = Regex.Replace("drop", "/kg", "drops", RegexOptions.IgnoreCase);
            s = Regex.Replace("@", "/kg", "(at)", RegexOptions.IgnoreCase);
            // s = Regex.Replace("update", "/kg", "updates", RegexOptions.IgnoreCase);
            //s = Regex.Replace("insert", "/kg", "inserts", RegexOptions.IgnoreCase);


            return s;
        }
        public static String RemoveHtmlTangs(String s)
        {
            if (!string.IsNullOrEmpty(s))
            {
                return Regex.Replace(s, @"<.*?>", string.Empty);

            }
            else { return s; }

        }
        #region const
        public const string uniChars =
          "àáảãạâầấẩẫậăằắẳẵặèéẻẽẹêềếểễệđìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵÀÁẢÃẠÂẦẤẨẪẬĂẰẮẲẴẶÈÉẺẼẸÊỀẾỂỄỆĐÌÍỈĨỊÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢÙÚỦŨỤƯỪỨỬỮỰỲÝỶỸỴÂĂĐÔƠƯ";

        public const string KoDauChars = "aaaaaaaaaaaaaaaaaeeeeeeeeeeediiiiiooooooooooooooooouuuuuuuuuuuyyyyyAAAAAAAAAAAAAAAAAEEEEEEEEEEEDIIIIIOOOOOOOOOOOOOOOOOUUUUUUUUUUUYYYYYAADOOU";
        #endregion
        public static bool isVnPhone(String input)
        {
            bool valid = true;

            if (input != null && input.Length > 9)
            {
                input = input.Replace(" ", String.Empty).Trim();
                input = input.Replace("+", "0").Replace("-", "").Replace(".", "");


                if (input.Length < 10 || input.Length > 16)
                {
                    valid = false;
                }
            }
            else
            {
                valid = false;
            }

            try
            {
                Convert.ToDouble(input);
                valid = true;
            }
            catch (Exception)
            {

                valid = false;
            }


            return valid;
        }
        public static string UnicodeToKoDau(string s)
        {
            string retVal = String.Empty;
            int pos;
            for (int i = 0; i < s.Length; i++)
            {
                pos = uniChars.IndexOf(s[i].ToString());
                if (pos >= 0)
                    retVal += KoDauChars[pos];
                else
                    retVal += s[i];
            }
            return retVal;
        }
        public static string ToURLgach(String title)
        {
            title = UnicodeToKoDau(title).ToLower();
            Regex regex = new Regex("[^a-zA-Z0-9 -]");
            title = regex.Replace(title, String.Empty);


            if (title.Length > 35)
            {
                title = title.Substring(0, 35);

            }
            title = title.Trim().ToLower();
            title = title.Replace(" ", "-").Replace(@"--", "-");
            return title.Replace(@"--", "-").Replace(@"–", "");
        }
        public static String ConVertToMoneyString(String s)
        {

            try
            {

                int i = s.Length;
                if (i <= 3)
                {
                    return s;
                }
                else
                {
                    int j = i % 3;
                    int k = i / 3;
                    String s1 = s.Substring(0, j);
                    s.Insert(3, ",");
                    String sss = " ";
                    for (int ii = 0; ii < k; ii++)
                    {
                        if (ii == k - 1)
                        {
                            sss += s.Substring(j, 3);

                        }
                        else
                        {
                            sss += s.Substring(j, 3) + ",";
                        }
                        j += 3;
                    }

                    if (s1.Equals("") || s1.Equals(" ") || s1 == null)
                    {
                        return sss;
                    }
                    else
                    {
                        return s1 + "," + sss;
                    }



                }

            }
            catch (Exception)
            {

                throw;
            }
        }
        public static string toURLgachTag(String title)
        {
            title = UnicodeToKoDau(title);
            Regex regex = new Regex("[^a-zA-Z0-9 -,]");
            title = regex.Replace(title, String.Empty);
            if (title.Length > 150)
            {
                title = title.Substring(0, 150);

            }
            title = title.Trim().ToLower();
            title = title.Replace(" ", "-").Replace(@"--", "-");
            return title.Replace(@"--", "-").Replace(@"–", "");
        }
        public static String SubString(int maxLeng, String inPut)
        {
            if (!String.IsNullOrEmpty(inPut))
            {
                if (inPut.Length >= maxLeng)
                {
                    inPut = inPut.Substring(0, maxLeng - 2) + " ..";
                }
            }

            return inPut;


        }
        public static String ConVertToMoneyFormatInt(String s)
        {
            int dotIndex = s.LastIndexOf(".");
            if (s != null && !DBNull.Value.Equals(s))
            {
                if (s == "0" || s == "0.00")
                {
                    return "0";
                }
                if (s.Length > (dotIndex + 3) && dotIndex != -1)
                {
                    s = s.Substring(0, dotIndex + 2);

                }
                return string.Format("{0:##,###}", Convert.ToDecimal(s));

            }
            else
            {
                return "0";
            }
        }
        public static String ConVertToMoneyFormat(String s)
        {
            int dotIndex = s.LastIndexOf(".");
            if (s != null && !DBNull.Value.Equals(s))
            {
                if (s == "0" || s == "0.00")
                {
                    return "0";
                }
                if (s.Length > (dotIndex + 3) && dotIndex != -1)
                {
                    s = s.Substring(0, dotIndex + 2);

                }
                return string.Format("{0:##,###.00}", Convert.ToDecimal(s));

            }
            else
            {
                return null;
            }
        }
        public static string toURLEncode(String title)
        {

            return System.Web.HttpUtility.UrlEncode(title);
        }
        public static string ToSplitURLgach(String title)
        {
            title = RemoveHtmlTangs(title);

            title = UnicodeToKoDau(title);
            Regex regex = new Regex("[^a-zA-Z0-9 -]");
            title = regex.Replace(title, String.Empty);
            if (title.Length > 50)
            {
                title = title.Substring(0, 50);

            }
            title = title.Trim();
            title = title.Replace("'", String.Empty).Replace("|", String.Empty).Replace(" ", "-").Replace("!", "").Replace(" ", "-").Replace(@"\", String.Empty).Replace(@"/", String.Empty).Replace(@"?", "").Replace(@"<", "").Replace(@">", "").Replace(@"(", "").Replace(@")", "").Replace(@"--", "-").Replace(@":", String.Empty);
            return System.Web.HttpUtility.UrlEncode(title).Replace(@"%0", "").Replace(@"%1", "").Replace(@"%2c", ",").Replace(@"%3a", String.Empty);
        }

        /// <summary>
        /// Chuyển dạng số dang dạng chứ đọc tiếng vie
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static string ToStringVN(Decimal number)
        {
            string s = number.ToString("#");
            string[] so = new string[] { "không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín" };
            string[] hang = new string[] { "", "nghìn", "triệu", "tỷ" };
            int i, j, donvi, chuc, tram;
            string str = " ";
            bool booAm = false;
            double decS = 0;
            //Tung addnew
            try
            {
                decS = Convert.ToDouble(s.ToString());
            }
            catch
            {
            }
            if (decS < 0)
            {
                decS = -decS;
                s = decS.ToString();
                booAm = true;
            }
            i = s.Length;
            if (i == 0)
                str = so[0] + str;
            else
            {
                j = 0;
                while (i > 0)
                {
                    donvi = Convert.ToInt32(s.Substring(i - 1, 1));
                    i--;
                    if (i > 0)
                        chuc = Convert.ToInt32(s.Substring(i - 1, 1));
                    else
                        chuc = -1;
                    i--;
                    if (i > 0)
                        tram = Convert.ToInt32(s.Substring(i - 1, 1));
                    else
                        tram = -1;
                    i--;
                    if ((donvi > 0) || (chuc > 0) || (tram > 0) || (j == 3))
                        str = hang[j] + str;
                    j++;
                    if (j > 3) j = 1;
                    if ((donvi == 1) && (chuc > 1))
                        str = "một " + str;
                    else
                    {
                        if ((donvi == 5) && (chuc > 0))
                            str = "lăm " + str;
                        else if (donvi > 0)
                            str = so[donvi] + " " + str;
                    }
                    if (chuc < 0)
                        break;
                    else
                    {
                        if ((chuc == 0) && (donvi > 0)) str = "lẻ " + str;
                        if (chuc == 1) str = "mười " + str;
                        if (chuc > 1) str = so[chuc] + " mươi " + str;
                    }
                    if (tram < 0) break;
                    else
                    {
                        if ((tram > 0) || (chuc > 0) || (donvi > 0)) str = so[tram] + " trăm " + str;
                    }
                    str = " " + str;
                }
            }
            if (booAm) str = "Âm " + str;
            return UppercaseFirst(str) + "đồng chẵn.";
        }
        public static string ToStringVN(int number)
        {
            string s = number.ToString("#");
            string[] so = new string[] { "không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín" };
            string[] hang = new string[] { "", "nghìn", "triệu", "tỷ" };
            int i, j, donvi, chuc, tram;
            string str = " ";
            double decS = 0;
            //Tung addnew
            try
            {
                decS = Convert.ToDouble(s.ToString());
            }
            catch
            {
            }
            if (decS < 0)
            {
                decS = -decS;
                s = decS.ToString();
            }
            i = s.Length;
            if (i == 0)
                str = so[0] + str;
            else
            {
                j = 0;
                while (i > 0)
                {
                    donvi = Convert.ToInt32(s.Substring(i - 1, 1));
                    i--;
                    if (i > 0)
                        chuc = Convert.ToInt32(s.Substring(i - 1, 1));
                    else
                        chuc = -1;
                    i--;
                    if (i > 0)
                        tram = Convert.ToInt32(s.Substring(i - 1, 1));
                    else
                        tram = -1;
                    i--;
                    if ((donvi > 0) || (chuc > 0) || (tram > 0) || (j == 3))
                        str = hang[j] + str;
                    j++;
                    if (j > 3) j = 1;
                    if ((donvi == 1) && (chuc > 1))
                        str = "một " + str;
                    else
                    {
                        if ((donvi == 5) && (chuc > 0))
                            str = "lăm " + str;
                        else if (donvi > 0)
                            str = so[donvi] + " " + str;
                    }
                    if (chuc < 0)
                        break;
                    else
                    {
                        if ((chuc == 0) && (donvi > 0)) str = "lẻ " + str;
                        if (chuc == 1) str = "mười " + str;
                        if (chuc > 1) str = so[chuc] + " mươi " + str;
                    }
                    if (tram < 0) break;
                    else
                    {
                        if ((tram > 0) || (chuc > 0) || (donvi > 0)) str = so[tram] + " trăm " + str;
                    }
                    str = " " + str;
                }
            }
            return UppercaseFirst(str);
        }

        static string UppercaseFirst(string s)
        {
            // Check for empty string.
            if (string.IsNullOrEmpty(s))
            {
                return string.Empty;
            }
            // Return char and concat substring.
            return char.ToUpper(s[0]) + s.Substring(1);
        }
    }
    public static class Times
    {
        public static String GetCurentYearYYYYMMDDdHhmm(Boolean isBeginYear)
        {
            if (isBeginYear)
            {
                DateTime dt = DateTime.Now;


                String s6 = dt.Year.ToString();

                return s6 + "00000000";
            }
            else
            {
                DateTime dt = DateTime.Now;
                String s6 = dt.Year.ToString();
                return s6 + "99999999";
            }


        }
        public static String GetCurentMonthYYYYMMDDdHhmm(Boolean isBeginMonth)
        {
            if (isBeginMonth)
            {
                DateTime dt = DateTime.Now;

                String s5 = dt.Month.ToString();
                String s6 = dt.Year.ToString();
                if (s5.Length == 1)
                {
                    s5 = "0" + s5;
                }
                return s6 + s5 + "000000";
            }
            else
            {
                DateTime dt = DateTime.Now;

                String s5 = dt.Month.ToString();
                String s6 = dt.Year.ToString();
                if (s5.Length == 1)
                {
                    s5 = "0" + s5;
                }
                return s6 + s5 + "999999";
            }


        }
        public static String GetyyyyMMddhhmm(string dateTimeFormat)
        {
            try
            {
                if (!string.IsNullOrEmpty(dateTimeFormat))
                {
                    String[] z = dateTimeFormat.Split('/');
                    if (z.Length > 2)
                    {
                        if (z[1].Length == 1)
                        {
                            z[1] = "0" + z[1];
                        }
                        if (z[0].Length == 1)
                        {
                            z[0] = "0" + z[0];
                        }
                        return z[2] + z[1] + z[0] + "2460";
                    }
                    else
                    {
                        return dateTimeFormat;
                    }

                }
            }
            catch (Exception)
            {

                return "0";
            }
            return "0";
        }
        public static String GetyyyyMMddhhmm(string dateTimeFormat, Boolean isMinimize)
        {
            try
            {
                if (!string.IsNullOrEmpty(dateTimeFormat))
                {
                    String[] z = dateTimeFormat.Split('/');
                    if (z.Length > 2)
                    {
                        if (z[1].Length == 1)
                        {
                            z[1] = "0" + z[1];
                        }
                        if (z[0].Length == 1)
                        {
                            z[0] = "0" + z[0];
                        }
                        if (isMinimize)
                        {
                            return z[2] + z[1] + z[0] + "0000";
                        }
                        else
                        {
                            return z[2] + z[1] + z[0] + "2460";
                        }
                    }
                    else
                    {
                        return dateTimeFormat;
                    }

                }
            }
            catch (Exception)
            {

                return "0";
            }
            return "0";
        }
        public static String GetyyyyMMdd(string dateTimeFormat)
        {
            try
            {
                if (!string.IsNullOrEmpty(dateTimeFormat))
                {
                    String[] z = dateTimeFormat.Split('/');
                    if (z.Length > 2)
                    {
                        if (z[1].Length == 1)
                        {
                            z[1] = "0" + z[1];
                        }
                        if (z[0].Length == 1)
                        {
                            z[0] = "0" + z[0];
                        }
                        return z[2] + z[1] + z[0];
                    }
                    else
                    {
                        return "";
                    }

                }
            }
            catch (Exception)
            {

                return "0";
            }
            return "0";
        }
        /// <summary>
        /// trả về chuỗi ngày tháng yyyymmddmmss
        /// </summary>
        /// <returns></returns>
        /// 

        public static String YYYYMMDDNow()
        {
            DateTime dt = DateTime.Now;

            String s4 = dt.Day.ToString();
            String s5 = dt.Month.ToString();
            String s6 = dt.Year.ToString();
            if (s5.Length == 1)
            {
                s5 = "0" + s5;
            }
            if (s4.Length == 1)
            {
                s4 = "0" + s4;
            }

            return s6 + s5 + s4;

        }
        public static String YYYYMMDDdmmssNow()
        {
            DateTime dt = DateTime.Now;

            String s1 = dt.Second.ToString();
            String s2 = dt.Minute.ToString();
            String s3 = dt.Hour.ToString();
            String s4 = dt.Day.ToString();
            String s5 = dt.Month.ToString();
            String s6 = dt.Year.ToString();
            if (s5.Length == 1)
            {
                s5 = "0" + s5;
            }
            if (s4.Length == 1)
            {
                s4 = "0" + s4;
            }
            if (s3.Length == 1)
            {
                s3 = "0" + s3;
            }
            if (s2.Length == 1)
            {
                s2 = "0" + s2;
            }
            if (s1.Length == 1)
            {
                s1 = "0" + s1;
            }
            return s6 + s5 + s4 + s3 + s2 + s1;

        }
        public static String GetFistDayOfMonthNow_yyyyMMddhhmm(bool isExactly)
        {
            DateTime dt = DateTime.Now;


            String s2 = "";
            String s3 = "";
            String s5 = dt.Month.ToString();
            int thisDay = dt.Day;
            if (thisDay < 15 && !isExactly)
            {
                s5 = (dt.Month - 1).ToString();
            }
            else
            {
                s5 = dt.Month.ToString();
            }
            String s4 = "01";


            String s6 = dt.Year.ToString();
            if (s5.Length == 1)
            {
                s5 = "0" + s5;
            }
            if (s4.Length == 1)
            {
                s4 = "0" + s4;
            }
            s2 = "00";
            s3 = "00";




            return s6 + s5 + s4 + s3 + s2;

        }
        public static String GetFistTimeOfthisMonth_yyyyMMddhhmm(Boolean isMinTime)
        {
            DateTime dt = DateTime.Now;


            String s2 = "";
            String s3 = "";
            String s4 = "01";
            String s5 = dt.Month.ToString();
            String s6 = dt.Year.ToString();
            if (s5.Length == 1)
            {
                s5 = "0" + s5;
            }
            if (isMinTime)
            {

                s2 = "00";
                s3 = "00";


            }
            else
            {
                s2 = "60";
                s3 = "24";
            }

            return s6 + s5 + s4 + s3 + s2;

        }
        public static String GetyyyyMMddhhmmNow(Boolean isMinTime)
        {
            DateTime dt = DateTime.Now;


            String s2 = "";
            String s3 = "";
            String s4 = dt.Day.ToString();
            String s5 = dt.Month.ToString();
            String s6 = dt.Year.ToString();
            if (s5.Length == 1)
            {
                s5 = "0" + s5;
            }
            if (s4.Length == 1)
            {
                s4 = "0" + s4;
            }
            if (isMinTime)
            {

                s2 = "00";
                s3 = "00";


            }
            else
            {
                s2 = "60";
                s3 = "24";
            }

            return s6 + s5 + s4 + s3 + s2;

        }
        public static String GetyyyyMMddhhmmNow()
        {
            DateTime dt = DateTime.Now;


            String s2 = dt.Minute.ToString();
            String s3 = dt.Hour.ToString();
            String s4 = dt.Day.ToString();
            String s5 = dt.Month.ToString();
            String s6 = dt.Year.ToString();
            if (s5.Length == 1)
            {
                s5 = "0" + s5;
            }
            if (s4.Length == 1)
            {
                s4 = "0" + s4;
            }
            if (s3.Length == 1)
            {
                s3 = "0" + s3;
            }
            if (s2.Length == 1)
            {
                s2 = "0" + s2;
            }

            return s6 + s5 + s4 + s3 + s2;

        }
        /// <summary>
        /// trả về một chuỗi thời gian hiện tại yyyymmddhhssms
        /// </summary>
        /// <returns>trả về một chuỗi thời gian hiện tại yyyymmddssmm 16 char</returns>
        public static String GetYYYYMMDDHHmmssmsNow()
        {
            DateTime dt = DateTime.Now;
            String s = dt.Millisecond.ToString();
            String s1 = dt.Second.ToString();
            String s2 = dt.Minute.ToString();
            String s3 = dt.Hour.ToString();
            String s4 = dt.Day.ToString();
            String s5 = dt.Month.ToString();
            String s6 = dt.Year.ToString();

            if (s5.Length == 1)
            {
                s5 = "0" + s5;
            }
            if (s4.Length == 1)
            {
                s4 = "0" + s4;
            }
            if (s3.Length == 1)
            {
                s3 = "0" + s3;
            }
            if (s2.Length == 1)
            {
                s2 = "0" + s2;
            }
            if (s1.Length == 1)
            {
                s1 = "0" + s1;
            }
            if (s.Length == 1)
            {
                s = "0" + s;
            }
            if (s.Length > 2)
            {
                s = s.Substring(0, 2);
            }
            return s6 + s5 + s4 + s3 + s2 + s1 + s;

        }
        public static String getSortStringByTimeNow()
        {
            DateTime dt = DateTime.Now;
            String s5 = dt.Month.ToString();
            String s6 = dt.Year.ToString();
            return s5 + s6;

        }


        /// <summary>
        /// dd/mm/yyyy
        /// </summary>
        /// <param name="YYYYMMddhhmmss">YYYYMMddhhmmss</param>
        /// <returns>dd/mm/yyyy</returns>
        public static String convertStringToTimeForMat(String YYYYMMddhhmmss)
        {
            try
            {
                if (!string.IsNullOrEmpty(YYYYMMddhhmmss))
                {
                    String year = "";
                    String month = "";
                    String day = "";
                    String hour = "";
                    String minute = "";
                    if (YYYYMMddhhmmss.Length == 8)
                    {
                        year = YYYYMMddhhmmss.Substring(0, 4);
                        month = YYYYMMddhhmmss.Substring(4, 2);
                        day = YYYYMMddhhmmss.Substring(6, 2);
                    }
                    else if (YYYYMMddhhmmss.Length >= 12)
                    {
                        year = YYYYMMddhhmmss.Substring(0, 4);
                        month = YYYYMMddhhmmss.Substring(4, 2);
                        day = YYYYMMddhhmmss.Substring(6, 2);
                        hour = " " + YYYYMMddhhmmss.Substring(8, 2)+"h ";
                        minute = ":" + YYYYMMddhhmmss.Substring(10, 2);

                    }


                    return day + "/" + month + "/" + year + hour+ minute;
                }
                else
                {
                    return "";
                }
            }
            catch (Exception)
            {

                return "0";
            }


        }
        public static String convertStringToTimeForMatVN(String YYYYMMddhhmmss)
        {
            try
            {
                if (YYYYMMddhhmmss.Length >= 8)
                {
                    String year = YYYYMMddhhmmss.Substring(0, 4);
                    String month = YYYYMMddhhmmss.Substring(4, 2);
                    String day = YYYYMMddhhmmss.Substring(6, 2);
                    return day + " tháng " + month + " năm " + year;
                }
                else
                {
                    return "0";
                }
            }
            catch (Exception)
            {

                return "0";
            }


        }
        /// <summary>
        /// trả về chuỗi thời gian được cộng trước
        /// </summary>
        /// <param name="dayToadd">int day toadd</param>
        /// <returns>yyyymmddhhmmss</returns>
        public static String returnTimestringAndAddDay(int dayToadd)
        {
            DateTime dt = DateTime.Now.AddDays(dayToadd);
            String s2 = dt.Minute.ToString();
            String s3 = dt.Hour.ToString();
            String s4 = dt.Day.ToString();
            String s5 = dt.Month.ToString();
            String s6 = dt.Year.ToString();
            if (s5.Length == 1)
            {
                s5 = "0" + s5;
            }
            if (s4.Length == 1)
            {
                s4 = "0" + s4;
            }
            if (s3.Length == 1)
            {
                s3 = "0" + s3;
            }
            if (s2.Length == 1)
            {
                s2 = "0" + s2;
            }
            return s6 + s5 + s4 + s3 + s2;

        }
        public static String returnyyyyMMddNowgAndAddMonth(int Month)
        {
            DateTime dt = DateTime.Now.AddMonths(Month);
            String s4 = dt.Day.ToString();
            String s5 = dt.Month.ToString();
            String s6 = dt.Year.ToString();
            if (s5.Length == 1)
            {
                s5 = "0" + s5;
            }
            if (s4.Length == 1)
            {
                s4 = "0" + s4;
            }

            return s6 + s5 + s4;

        }
        public static String GetyyyyMMddNowgAndAddMonth(string fromTime, int Month)
        {

            String s4 = fromTime.Substring(6, 2);
            String s5 = fromTime.Substring(4, 2);
            int currentMonth = Convert.ToInt32(s5) + Month;
            int yearAdd = 0;
            if (currentMonth > 12)
            {
                yearAdd = currentMonth / 12;
                currentMonth = currentMonth % 12;

            }
            s5 = currentMonth.ToString();
            String s6 = fromTime.Substring(0, 4);
            s6 = (Convert.ToInt32(s6) + yearAdd).ToString();
            if (s5.Length == 1)
            {
                s5 = "0" + s5;
            }
            if (s4.Length == 1)
            {
                s4 = "0" + s4;
            }

            return s6 + s5 + s4;

        }
        /// <summary>
        /// convert Time dd/mm/yyyy FormatToString yyyymmdd
        /// </summary>
        /// <param name="time">dd/mm/yyyy</param>
        /// <returns>yyyymmdd</returns>
        public static String convertTimeFormatToString(String time)
        {
            try
            {
                String[] s = time.Split('/');
                return s[2] + s[1] + s[0];
            }
            catch (Exception)
            {

                return "";
            }
        }
        public static String GetTimeFromYYYYmmddhhmmss(String s)
        {
            try
            {
                if (s.Length >= 12)
                {
                    return s.Substring(6, 2) + @"/" + s.Substring(4, 2) + "/" + s.Substring(0, 4) + " - " + s.Substring(8, 2) + ":" + s.Substring(10, 2);
                }
                else
                {
                    return s.Substring(6, 2) + @"/" + s.Substring(4, 2) + "/" + s.Substring(0, 4);
                }
            }
            catch (Exception)
            {
                return "dd/mm/yyyy";

            }

        }
        public static String GetTimeFromYYYYmmddhhmmssV2(String s)
        {
            try
            {
                if (s.Length >= 12)
                {
                    return s.Substring(6, 2) + " tháng " + s.Substring(4, 2) + ", " + s.Substring(0, 4) + " " + s.Substring(8, 2) + ":" + s.Substring(10, 2);
                }
                else
                {
                    return s.Substring(6, 2) + @"/" + s.Substring(4, 2) + "/" + s.Substring(0, 4);
                }
            }
            catch (Exception)
            {
                return "dd/mm/yyyy";

            }

        }
    }
}
